package com.example.android.miwok;

public class word {
    private String mdefaulttranslation;
    private String mmiwoktranslation;
    private int mimageId;
    private int msongId;
 public word(String defaulttranslation,String miwoktranslation,int imageid,int songid)
 {
     mdefaulttranslation=defaulttranslation;
     mmiwoktranslation=miwoktranslation;
     mimageId=imageid;
     msongId=songid;
 }
 public word(String ddefaulttranslation,String dmiwoktranslation,int songid)
 {
  mdefaulttranslation=ddefaulttranslation;
  mmiwoktranslation=dmiwoktranslation;
  msongId=songid;
 }
 public String getdefaulttranslation()
 {
     return mdefaulttranslation;
 }
 public String getmiwoktranslation()
 {
     return mmiwoktranslation;
 }
 public int getImageResourceId()
 {
     return mimageId;
 }
 public int getSongId()
 {
     return msongId;
 }

    @Override
    public String toString() {
        return "word{" +
                "mdefaulttranslation='" + mdefaulttranslation + '\'' +
                ", mmiwoktranslation='" + mmiwoktranslation + '\'' +
                ", mimageId=" + mimageId +
                ", msongId=" + msongId +
                '}';
    }
}
