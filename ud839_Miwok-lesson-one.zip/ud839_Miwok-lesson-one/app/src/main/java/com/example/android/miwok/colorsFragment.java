package com.example.android.miwok;


import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class colorsFragment extends Fragment {
    MediaPlayer play;

    public colorsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onStop() {
        super.onStop();
        releaseMediaPlayer();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        final ArrayList<word> words1 = new ArrayList<word>();
        words1.add(new word("white","telupu",R.raw.color_white));
        words1.add(new word("red","telupu",R.raw.color_red));
        words1.add(new word("yellow","akupacha",R.raw.color_dusty_yellow));

        word word1=words1.get(0);
        //word word2=words1.get(1);
        //word word3=words1.get(2);
        Log.i("colorsFragment","result is"+word1);
        ListView listView1 = (ListView) rootView.findViewById(R.id.list);
        // Create a list of words
        wordadapter adapter1 = new wordadapter(getActivity(),words1);
        listView1.setAdapter(adapter1);
        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                word getItem=words1.get(position);
                releaseMediaPlayer();
                play=MediaPlayer.create(getActivity(),getItem.getSongId());
                play.start();
                play.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        releaseMediaPlayer();
                    }
                });
            }
        });

        return rootView;
    }
    private void releaseMediaPlayer() {
        // If the media player is not null, then it may be currently playing a sound.
        if (play != null) {
            // Regardless of the current state of the media player, release its resources
            // because we no longer need it.
            play.release();

            // Set the media player back to null. For our code, we've decided that
            // setting the media player to null is an easy way to tell that the media player
            // is not configured to play an audio file at the moment.
            play = null;
        }
    }
}
